 /*
	Creation date: 03 / 06 / 2020
	last update: 08 / 06 / 2020
	updater: Andrade, J. V.
	REV: 0.001
	Reviewer: J., Doe
	Review Date: -- / -- / --

	The REV number represents:
		- 0.XXX: JS version
		- X.000: Iteration
*/ 

var digitalValve = class{
	constructor (
		tag,
		posX,
		posY,
		rotation,
		status,
		command
	) {
		this.tag = tag;
		this.posX = posX;
		this.posY = posY;
		this.rotation = rotation;
		this.status = status;
		this.command = command;
		drawValve(this.tag, this.posX, this.posY, this.rotation, this.status);
	}	
}

/*function drawValve(tag, xPos, yPos, angle, status){

	let projectWidth = project.clientWidth;
	let gridScale = defineGridscale();

	let g = defineSubdivision()[0];
	let G = defineSubdivision()[1];

	let x = xPos * g;
	let y = yPos * g;

	let x1 = x + (2 * g);
	let y1 = y + (2 * g);
	let x2 = x + (G / 2);
	let y2 = y + (G / 2);
	let x3 = x + G - (2 * g);
	let y3 = y + G - (2 * g);

	let l = 3 * g;															// Valve symbol radius
	let radians = Math.round(1000 * (angle * (Math.PI / 180))) / 1000;
	let sinR = Math.round(Math.sin(radians) * 1000) / 1000;
	let cosR = Math.round(Math.cos(radians) * 1000) / 1000;
	let lsin = l * sinR;
	let lcos = l * cosR;
	
	let valveInX = x1 + lsin;
	let valveInY = y1 + lcos;
	let valveOutX = x3 - lsin;
	let valveOutY = y3 - lcos;

	let valveIn = [valveInX, valveInY];
	let valveOut = [valveOutX, valveOutY];

	ctx.save();

	// Rotates the valve 180° when needed
	//if(radians !== "0"){
	//	// Rotates the canvas
	//	ctx.translate((x + G  / 2), (y + G / 2));
	//	ctx.rotate(radians);
	//	ctx.translate(((-1) * (x + G / 2)), ((-1) * (y + G / 2)));
	//}
	//else{
	//	// Restore the canvas to original position
	//	ctx.restore();
	//}

	// Draw bezel
	ctx.beginPath();
	ctx.moveTo(x, y);
	ctx.lineTo(x+G, y);
	ctx.lineTo(x+G, y+G);
	ctx.lineTo(x, y+G);
	ctx.lineTo(x, y);
	ctx.lineWidth = 2;
	ctx.strokeStyle = "#FFFF80"
	ctx.stroke();

	// Draw internal valve symbol

	// Input Triangle
   	ctx.beginPath();
	ctx.lineWidth = 2;
	ctx.moveTo(x1 , y1);
	ctx.lineTo(x2-1, y2);
	ctx.lineTo(x1, y3);
	ctx.closePath();
	ctx.strokeStyle = "#00FF00"
	ctx.stroke();
	ctx.fillStyle = "grey";
	ctx.fill();

	// Output Triangle
   	ctx.beginPath();
	ctx.lineWidth = 2;
	ctx.moveTo(x2+1, y2);
	ctx.lineTo(x3, y1);
	ctx.lineTo(x3, y3);
	ctx.closePath();
	ctx.strokeStyle = "#00FF00"
	ctx.stroke();
	ctx.fillStyle = "grey";
	ctx.fill();

	// central line
	ctx.beginPath();
	ctx.lineWidth = 2;
	ctx.moveTo(x1-1, y2);
	ctx.lineTo(x3+1, y2);
	ctx.strokeStyle = "#0000FF"
	ctx.stroke();

	ctx.restore();

	return[valveIn, valveOut, radians];
}*/

function drawValve(tag, xPos, yPos, angle, status){

	let g = defineSubdivision()[0];											// Get project's smaller grid division
	let G = defineSubdivision()[1];											// Get project's greater grid division
	let l = 3 * g;															// Valve symbol radius

	// Define absolute valve position according to grid dimensions
	let x = xPos * g;
	let y = yPos * g;

	let radians = Math.round(1000 * (angle * (Math.PI / 180))) / 1000;		// Converts the rotation angle to radians
	let sinR = Math.round(Math.sin(radians) * 1000) / 1000;					// Calculates the rotation sine
	let cosR = Math.round(Math.cos(radians) * 1000) / 1000;					// Calculates the rotation cosine
	let lsin = l * sinR;													// Angle offset correction for Y axis
	let lcos = l * cosR;													// Angle offset correction for X axis

	console.log(tag + " sinR is: " + sinR + " cosR is: " + cosR);
	console.log(tag + " lsin is: " + lsin + " lcos is: " + lcos);

	// Calculates border and bezel points for drawing graphics
	let x0 = x + cosR;
	let y0 = y + sinR;

	// Calculates valve points fro drawing graphics
	let x1 = x + (2 * g) + cosR;
	let y1 = y + (2 * g) + sinR;
	let x2 = x + (G / 2) + cosR;
	let y2 = y + (G / 2) + sinR;
	let x3 = x + G - (2 * g) + cosR;
	let y3 = y + G - (2 * g) + sinR;

	let valveIn = [x1, y2];
	let valveOut = [x3, y2];

	// Draw bezel
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	ctx.lineTo((x0 + G), y0);
	ctx.lineTo((x0 + G), (y0 + G));
	ctx.lineTo(x0, (y0 + G));
	ctx.lineTo(x0, y0);
	ctx.lineWidth = 2;
	ctx.strokeStyle = "#FFFF80"
	ctx.stroke();

	// Draw internal valve symbol

	// Input Triangle
   	ctx.beginPath();
	ctx.lineWidth = 2;
	ctx.moveTo(x1 , y1);
	ctx.lineTo(x2-1, y2);
	ctx.lineTo(x1, y3);
	ctx.closePath();
	ctx.strokeStyle = "#00FF00"
	ctx.stroke();
	ctx.fillStyle = "grey";
	ctx.fill();

	// Output Triangle
   	ctx.beginPath();
	ctx.lineWidth = 2;
	ctx.moveTo(x2+1, y2);
	ctx.lineTo(x3, y1);
	ctx.lineTo(x3, y3);
	ctx.closePath();
	ctx.strokeStyle = "#00FF00"
	ctx.stroke();
	ctx.fillStyle = "grey";
	ctx.fill();

	// central line
	ctx.beginPath();
	ctx.lineWidth = 2;
	ctx.moveTo(x1-1, y2);
	ctx.lineTo(x3+1, y2);
	ctx.strokeStyle = "#0000FF"
	ctx.stroke();

	ctx.restore();

	return[valveIn, valveOut, radians];
}


function drawPipe(valve1, valve2){

	let projectWidth = project.clientWidth;
	let gridScale = defineGridscale();

	let g = defineSubdivision(projectWidth, gridScale)[0];
	let G = defineSubdivision(projectWidth, gridScale)[1];

	v1_input = valve1[0];
	v1_output = valve1[1];
	v1_rotation = valve1[2];

	v1_inX = v1_input[0];
	v1_inY = v1_input[1];
	v1_outX = v1_output[0];
	v1_outY = v1_output[1];

	v2_input = valve2[0];
	v2_output = valve2[1];
	v2_rotation = valve2[2];

	v2_inX = v2_input[0];
	v2_inY = v2_input[1];
	v2_outX = v2_output[0];
	v2_outY = v2_output[1];

	let point1 = [0, 0];
	let point2 = [0, 0];

	if((v1_rotation == "90") || (v1_rotation == "270")){

		console.log("Valve is in VERTICAL position");

		if(v1_inY > v1_outY){
			console.log("Output on TOP");
			point1[0] = v1_outX;
			point1[1] = v1_outY - g;
		}
		else {
			console.log("Output on BOTTOM");
			point1[0] = v1_outX;
			point1[1] = v1_outY + g;
		}
	}
	else if((v1_rotation == "0") || (v1_rotation == "90")){

		console.log("Valve is in HORIZONTAL position");
		console.log("v1_inX = " + v1_input[0]
		+ "\n" + "v1_inY = " + v1_input[1]
		+ "\n" + "v1_outX = " + v1_output[0]
		+ "\n" + "v1_outY = " + v1_output[1]);

		if(v1_inX < v1_outX){
			console.log("Output on RIGHT");
			point1[0] = v1_outX + g;
			point1[1] = v1_outY;
		}
		else {
			console.log("Output on LEFT");
			point1[0] = v1_outX - g;
			point1[1] = v1_outY;
		}

	}

	ctx.save();

	ctx.beginPath();
	ctx.moveTo(v1_outX, v1_outY);
	ctx.lineTo(point1[0], point1[1]);
	ctx.lineTo(v2_inX, v2_inY);
	ctx.lineWidth = 2;
	ctx.strokeStyle = "#FF0000"
	ctx.stroke();

	ctx.restore();
}

function nodeConnection(){
	// This node is used to make corners where the algorithm can't position directly
	// This also should function to connect different valve trees when needed
}