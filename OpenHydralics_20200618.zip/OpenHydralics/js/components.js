 /*
	Creation date: 03 / 06 / 2020
	last update: 08 / 06 / 2020
	updater: Andrade, J. V.
	REV: 0.001
	Reviewer: J., Doe
	Review Date: -- / -- / --

	The REV number represents:
		- 0.XXX: JS version
		- X.000: Iteration
*/ 

var digitalValve = class{
	constructor (
		tag,
		posX,
		posY,
		rotation,
		status,
		command
	) {
		this.tag = tag;
		this.posX = posX;
		this.posY = posY;
		this.rotation = rotation;
		this.status = status;
		this.command = command;
		drawValve(this.tag, this.posX, this.posY, this.rotation, this.status);
	}	
}

function drawValve(tag, xPos, yPos, angle, status){

	let g = defineSubdivision()[0];											// Get project's smaller grid division
	let G = defineSubdivision()[1];											// Get project's greater grid division

	let l = 3 * g;															// Valve symbol base length
	let L = G / 2;															// Valve bezel base legth

	let x = xPos * g;
	let y = yPos * g;

	let centreX = x + L;
	let centreY = y + L;

	let inputStatus;
	let outpuStatus;

	let commandOpen;
	let commandClose;

	// Calculates the hypothenusa from a triange in which the side is equivalent to the desired side width of the valve bezel
	let H = Math.round(Math.sqrt(2) * L * 1000) / 1000;
	let h = Math.round(Math.sqrt(2) * l * 1000) / 1000;

	//console.log("H is: " + H + " and h is: " + h
	//+ "\n" + "G is: " + G + " and g is: " + g
	//+ "\n" + "L is: " + L + " and l is: " + l
	//+ "\n" + "X is: " + x + " and Y is: " + y);
	//+ "\n" + "centreX is: " + centreX + " and centreY is: " + centreY);

	// Draw the outter bezel
	for (var i = 0; i <= 4; i++){

		let theta = i * 90 + 45;

		// Transforms the angle from degrees to radians
		let R = Math.round((angle + theta) * (Math.PI / 180) * 100) / 100;

		let sinR = Math.round(Math.sin(R) * 1000) / 1000;
		let cosR = Math.round(Math.cos(R) * 1000) / 1000;

		let thetaX = (Math.round(x + (H * sinR)) * 1000) / 1000 + L;
		let thetaY = (Math.round(y + (H * cosR)) * 1000) / 1000 + L;

		if(i == 0){
			ctx.beginPath();
			ctx.moveTo(thetaX, thetaY);
		}
		else if (i == 4){
			ctx.closePath();
			ctx.strokeStyle = "#FFFF80";
			ctx.stroke();
		}
		else {
			ctx.lineTo(thetaX, thetaY);
		}
	}

	// Draw valve
	for (var i = 0; i <= 6; i++){
		
		let alpha = (i * 90) + 135;

		// Transforms the angle from degrees to radians
		let r = Math.round((angle + alpha) * (Math.PI / 180) * 100) / 100;

		let sinr = Math.round(Math.sin(r) * 1000) / 1000;
		let cosr = Math.round(Math.cos(r) * 1000) / 1000;

		let alphaX = (Math.round(centreX + (h * sinr)) * 1000) / 1000 ;
		let alphaY = (Math.round(centreY + (h * cosr)) * 1000) / 1000 ;

		if(i == 0){
			// Begin input triangle
			ctx.beginPath();
			ctx.moveTo(centreX, centreY);
		}
		else if (i == 3){
			// End input triangle
			ctx.closePath();
			ctx.strokeStyle = "#808080";
			ctx.stroke();
			ctx.fillStyle = "#808080";
			ctx.fill();

			// Begin output triangle
			ctx.beginPath();
			ctx.moveTo(centreX, centreY);
			ctx.lineTo(alphaX,alphaY);
		}
		else if (i == 5){
			// End output triangle
			ctx.closePath();
			ctx.strokeStyle = "#808080";
			ctx.stroke();
			ctx.fillStyle = "#808080";
			ctx.fill();
		}
		else {
			ctx.lineTo(alphaX, alphaY);
		}

		//console.log("Alpha is: " + alpha + " and in radians it is: " + r
		//+ "\n" + "sinR is: " + sinr + " and cosR is: " + cosr
		//+ "\n" + "alphaX is: " + alphaX + " and alphaY is: " + alphaY);
	}

	let drawPipeIterations = 2;

	// draw inner pipe lines
	for(var i = 0; i <= drawPipeIterations; i++){

		let beta = i * 180 + 90;														// angle in degree
		let pipeExt = 4 * g;													// pipe extension

		// Transforms the angle from degrees to radians
		let b = Math.round((angle + beta) * (Math.PI / 180) * 100) / 100;

		let sinb = Math.round(Math.sin(b) * 1000) / 1000;
		let cosb = Math.round(Math.cos(b) * 1000) / 1000;

		let betaX = (Math.round(centreX + (h * sinb)) * 1000) / 1000;
		let betaY = (Math.round(centreY + (h * cosb)) * 1000) / 1000;		

		console.log("Beta is: " + beta + " and b is: " + b);

		//Draw

		if(i == 0){
			ctx.beginPath();
			ctx.moveTo(centreX, centreY);
		}
		else if(i == drawPipeIterations){
			ctx.strokeStyle = "#0000FF";
			ctx.stroke();
		}
		else{
			ctx.lineTo(betaX, betaY);
		}
	}

}

function drawPipe(valve1, valve2){

	let projectWidth = project.clientWidth;
	let gridScale = defineGridscale();

	let g = defineSubdivision(projectWidth, gridScale)[0];
	let G = defineSubdivision(projectWidth, gridScale)[1];

	v1_input = valve1[0];
	v1_output = valve1[1];
	v1_rotation = valve1[2];

	v1_inX = v1_input[0];
	v1_inY = v1_input[1];
	v1_outX = v1_output[0];
	v1_outY = v1_output[1];

	v2_input = valve2[0];
	v2_output = valve2[1];
	v2_rotation = valve2[2];

	v2_inX = v2_input[0];
	v2_inY = v2_input[1];
	v2_outX = v2_output[0];
	v2_outY = v2_output[1];

	let point1 = [0, 0];
	let point2 = [0, 0];

	if((v1_rotation == "90") || (v1_rotation == "270")){

		console.log("Valve is in VERTICAL position");

		if(v1_inY > v1_outY){
			console.log("Output on TOP");
			point1[0] = v1_outX;
			point1[1] = v1_outY - g;
		}
		else {
			console.log("Output on BOTTOM");
			point1[0] = v1_outX;
			point1[1] = v1_outY + g;
		}
	}
	else if((v1_rotation == "0") || (v1_rotation == "90")){

		console.log("Valve is in HORIZONTAL position");
		console.log("v1_inX = " + v1_input[0]
		+ "\n" + "v1_inY = " + v1_input[1]
		+ "\n" + "v1_outX = " + v1_output[0]
		+ "\n" + "v1_outY = " + v1_output[1]);

		if(v1_inX < v1_outX){
			console.log("Output on RIGHT");
			point1[0] = v1_outX + g;
			point1[1] = v1_outY;
		}
		else {
			console.log("Output on LEFT");
			point1[0] = v1_outX - g;
			point1[1] = v1_outY;
		}

	}

	ctx.save();

	ctx.beginPath();
	ctx.moveTo(v1_outX, v1_outY);
	ctx.lineTo(point1[0], point1[1]);
	ctx.lineTo(v2_inX, v2_inY);
	ctx.lineWidth = 2;
	ctx.strokeStyle = "#FF0000"
	ctx.stroke();

	ctx.restore();
}

function nodeConnection(){
	// This node is used to make corners where the algorithm can't position directly
	// This also should function to connect different valve trees when needed
}